package cofh.core.gui;

import net.minecraft.client.gui.GuiScreen;

public abstract class GuiBookCore extends GuiScreen {

	private GuiScreen prevScreen;

	@Override
	public void initGui() {

		super.initGui();
	}

}
