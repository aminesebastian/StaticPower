package cofh.core.util.core;

public class SlotConfig {

	/* Whether or not the SLOT allows input */
	public boolean[] allowInsertionSlot;

	/* Whether or not the SLOT allows extraction */
	public boolean[] allowExtractionSlot;

}