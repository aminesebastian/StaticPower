package cofh.api.item;

/**
 * Blank interface only used for checking against in custom recipes where NBT should be transferred to the result.
 */
public interface INBTCopyIngredient {

}
