package cofh.api;

public class CoFHAPIProps {

	private CoFHAPIProps() {

	}

	public static final String VERSION = "2.5.0";

}
